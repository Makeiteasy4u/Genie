# plugin.video.stalker

Kodi Stalker video add-on - all platforms

This is PTV Stalker6ghost Full working with 5 primium servers. i will update it permanently . please if you read this support my work by subscribe to my CHANNEL YOUTUBE AND SHARE MY VIDEOS . STAY TUNED MORE contents coming soon